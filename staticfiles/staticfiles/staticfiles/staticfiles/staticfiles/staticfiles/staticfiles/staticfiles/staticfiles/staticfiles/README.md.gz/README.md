# desktopminishop - Django / Stripe Payments

### System Integrator Website selling a premium desktop computer, built using django python framework and stripe for order/checkout, Hosted using Heroku.

### TODO:
    - Add dark mode
    - Include product feature video
    - Enroll in stripe beta for custom domain url checkout
    

### Preview:
#### Index:
![Preview1](/Screenshot%202021-05-06%20174953.png)
#### Features:
![Preview2](/Screenshot%202021-05-06%20174935.png)

